document.addEventListener("DOMContentLoaded", function() {
    const cartItems = document.querySelectorAll(".cart-item");

    // Function to update the total price
    function updateTotalPrice() {
        let totalPrice = 0;
        cartItems.forEach(item => {
            const priceElement = item.querySelector("p");
            const quantityInput = item.querySelector("input[type='number']");
            const price = parseFloat(priceElement.textContent.replace("Price: $", ""));
            const quantity = parseInt(quantityInput.value);
            totalPrice += price * quantity;
        });
        document.querySelector(".cart-total h2").textContent = `Total: $${totalPrice.toFixed(2)}`;
    }

    // Add event listeners for quantity input and remove button
    cartItems.forEach(item => {
        const quantityInput = item.querySelector("input[type='number']");
        const removeButton = item.querySelector(".remove-item");

        quantityInput.addEventListener("change", function() {
            updateTotalPrice();
        });

        removeButton.addEventListener("click", function() {
            item.remove();
            updateTotalPrice();
        });
    });

    // Initial total price calculation
    updateTotalPrice();
});
